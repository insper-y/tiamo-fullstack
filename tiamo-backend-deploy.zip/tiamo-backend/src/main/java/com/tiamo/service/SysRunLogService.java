package com.tiamo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.tiamo.entity.SysRunLog;
import java.util.List;
import java.util.Map;

/**
 * 系统运行日志 Service 接口
 */
public interface SysRunLogService extends IService<SysRunLog> {

    /**
     * 异步保存运行日志
     */
    void saveLogAsync(SysRunLog log);

    /**
     * 获取各层级调用统计
     */
    List<Map<String, Object>> getLevelStats();

    /**
     * 获取最近24小时每小时调用量
     */
    List<Map<String, Object>> getHourlyStats();

    /**
     * 获取异常最多的方法TOP10
     */
    List<Map<String, Object>> getTopErrorMethods();

    /**
     * 获取耗时最长的方法TOP10
     */
    List<Map<String, Object>> getTopSlowMethods();

    /**
     * 清理指定天数之前的日志
     */
    int cleanOldLogs(int days);

    /**
     * 清空当天的日志
     */
    int cleanTodayLogs();

    /**
     * 聚合统计：总调用量、今日调用量、异常总数、今日异常数
     */
    Map<String, Object> getAggregateStats();
}
