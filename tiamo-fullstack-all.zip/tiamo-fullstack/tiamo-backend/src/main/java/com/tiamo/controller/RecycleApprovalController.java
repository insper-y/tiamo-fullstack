package com.tiamo.controller;

import com.tiamo.annotation.OperationLog;
import com.tiamo.common.Result;
import com.tiamo.entity.RecycleApproval;
import com.tiamo.entity.SysUser;
import com.tiamo.security.JwtUtil;
import com.tiamo.service.RecycleApprovalService;
import com.tiamo.service.impl.SysUserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 回收站审批 Controller
 * 普通用户提交恢复/删除申请，管理员审批
 */
@RestController
@RequestMapping("/api/recycle-approval")
public class RecycleApprovalController {

    @Autowired
    private RecycleApprovalService approvalService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private SysUserServiceImpl userService;

    /**
     * 提交审批申请（普通用户）
     * POST /api/recycle-approval/submit
     * body: {"bookId": 1, "approvalType": "RESTORE"}
     */
    @PostMapping("/submit")
    @OperationLog(module = "回收站审批", description = "提交审批申请", operationType = "CREATE")
    public Result<RecycleApproval> submit(
            @RequestBody Map<String, Object> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        Integer bookId = request.get("bookId") != null ? Integer.valueOf(request.get("bookId").toString()) : null;
        String approvalType = (String) request.get("approvalType");
        if (bookId == null) {
            return new Result<>(400, null, "商品ID不能为空");
        }
        if (approvalType == null || (!"RESTORE".equals(approvalType) && !"DELETE".equals(approvalType))) {
            return new Result<>(400, null, "申请类型无效，RESTORE-恢复 DELETE-彻底删除");
        }
        try {
            RecycleApproval approval = approvalService.submitApproval(bookId, approvalType, user.getId(), user.getUsername());
            return new Result<>(200, approval, "申请已提交，等待管理员审批");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 审批通过（管理员）
     * PUT /api/recycle-approval/{id}/approve
     */
    @PutMapping("/{id}/approve")
    @OperationLog(module = "回收站审批", description = "审批通过", operationType = "UPDATE")
    public Result<String> approve(
            @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getAdminUser(authHeader);
        if (user == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可审批");
        }
        String remark = request != null ? request.get("remark") : null;
        try {
            approvalService.approve(id, user.getId(), user.getUsername(), remark);
            return new Result<>(200, null, "审批通过，操作已执行");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 审批拒绝（管理员）
     * PUT /api/recycle-approval/{id}/reject
     */
    @PutMapping("/{id}/reject")
    @OperationLog(module = "回收站审批", description = "审批拒绝", operationType = "UPDATE")
    public Result<String> reject(
            @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getAdminUser(authHeader);
        if (user == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可审批");
        }
        String remark = request != null ? request.get("remark") : null;
        try {
            approvalService.reject(id, user.getId(), user.getUsername(), remark);
            return new Result<>(200, null, "已拒绝申请");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 查询待审批列表（管理员）
     * GET /api/recycle-approval/pending
     */
    @GetMapping("/pending")
    public Result<List<RecycleApproval>> getPendingList(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getAdminUser(authHeader);
        if (user == null) {
            return new Result<>(403, null, "无权限访问");
        }
        List<RecycleApproval> list = approvalService.getPendingList();
        return new Result<>(200, list, "查询成功");
    }

    /**
     * 查询我的申请列表（所有登录用户）
     * GET /api/recycle-approval/my
     */
    @GetMapping("/my")
    public Result<List<RecycleApproval>> getMyApplications(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        List<RecycleApproval> list = approvalService.getMyApplications(user.getId());
        return new Result<>(200, list, "查询成功");
    }

    /**
     * 获取待审批数量（管理员）
     * GET /api/recycle-approval/pending-count
     */
    @GetMapping("/pending-count")
    public Result<Map<String, Object>> getPendingCount(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getAdminUser(authHeader);
        if (user == null) {
            return new Result<>(403, null, "无权限访问");
        }
        long count = approvalService.countPending();
        Map<String, Object> data = new java.util.HashMap<>();
        data.put("count", count);
        return new Result<>(200, data, "查询成功");
    }

    /**
     * 删除申请记录（申请人本人或管理员，必须已阅读）
     * DELETE /api/recycle-approval/{id}
     */
    @DeleteMapping("/{id}")
    @OperationLog(module = "回收站审批", description = "删除申请记录", operationType = "DELETE")
    public Result<String> delete(
            @PathVariable Long id,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        try {
            approvalService.deleteById(id, user.getId(), user.getRole());
            return new Result<>(200, null, "删除成功");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 标记为已阅读（申请人本人）
     * POST /api/recycle-approval/{id}/read
     */
    @PostMapping("/{id}/read")
    @OperationLog(module = "回收站审批", description = "标记为已阅读", operationType = "UPDATE")
    public Result<String> markAsRead(
            @PathVariable Long id,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        try {
            approvalService.markAsRead(id, user.getId());
            return new Result<>(200, null, "已标记为已阅读");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 一键阅读所有（申请人本人的已处理申请）
     * POST /api/recycle-approval/read-all
     */
    @PostMapping("/read-all")
    @OperationLog(module = "回收站审批", description = "一键阅读所有", operationType = "UPDATE")
    public Result<Map<String, Object>> markAllAsRead(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        try {
            int count = approvalService.markAllAsRead(user.getId());
            Map<String, Object> data = new java.util.HashMap<>();
            data.put("count", count);
            return new Result<>(200, data, "已阅读 " + count + " 条记录");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 一键清理所有已阅读的记录（申请人本人）
     * DELETE /api/recycle-approval/delete-read-all
     */
    @DeleteMapping("/delete-read-all")
    @OperationLog(module = "回收站审批", description = "一键清理所有已阅读记录", operationType = "DELETE")
    public Result<Map<String, Object>> deleteAllRead(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        try {
            int count = approvalService.deleteAllRead(user.getId());
            Map<String, Object> data = new java.util.HashMap<>();
            data.put("count", count);
            return new Result<>(200, data, "已清理 " + count + " 条已阅读记录");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 批量通过申请（管理员）
     * PUT /api/recycle-approval/batch-approve
     */
    @PutMapping("/batch-approve")
    @OperationLog(module = "回收站审批", description = "批量通过申请", operationType = "UPDATE")
    public Result<Map<String, Object>> batchApprove(
            @RequestBody Map<String, Object> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getAdminUser(authHeader);
        if (user == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可批量审批");
        }
        try {
            @SuppressWarnings("unchecked")
            List<Object> rawIds = (List<Object>) request.get("ids");
            String remark = request.get("remark") != null ? request.get("remark").toString() : null;
            if (rawIds == null || rawIds.isEmpty()) {
                return new Result<>(400, null, "请选择要处理的申请");
            }
            List<Long> ids = new java.util.ArrayList<>();
            for (Object id : rawIds) {
                ids.add(Long.valueOf(id.toString()));
            }
            int count = approvalService.batchApprove(ids, user.getId(), user.getUsername(), remark);
            Map<String, Object> data = new java.util.HashMap<>();
            data.put("count", count);
            return new Result<>(200, data, "已通过 " + count + " 条申请");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 批量拒绝申请（管理员）
     * PUT /api/recycle-approval/batch-reject
     */
    @PutMapping("/batch-reject")
    @OperationLog(module = "回收站审批", description = "批量拒绝申请", operationType = "UPDATE")
    public Result<Map<String, Object>> batchReject(
            @RequestBody Map<String, Object> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getAdminUser(authHeader);
        if (user == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可批量审批");
        }
        try {
            @SuppressWarnings("unchecked")
            List<Object> rawIds = (List<Object>) request.get("ids");
            String remark = request.get("remark") != null ? request.get("remark").toString() : null;
            if (rawIds == null || rawIds.isEmpty()) {
                return new Result<>(400, null, "请选择要处理的申请");
            }
            List<Long> ids = new java.util.ArrayList<>();
            for (Object id : rawIds) {
                ids.add(Long.valueOf(id.toString()));
            }
            int count = approvalService.batchReject(ids, user.getId(), user.getUsername(), remark);
            Map<String, Object> data = new java.util.HashMap<>();
            data.put("count", count);
            return new Result<>(200, data, "已拒绝 " + count + " 条申请");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /**
     * 批量提交审批申请（普通用户）
     * POST /api/recycle-approval/batch-submit
     * body: {"bookIds": [1,2,3], "approvalType": "RESTORE"}
     */
    @PostMapping("/batch-submit")
    @OperationLog(module = "回收站审批", description = "批量提交审批申请", operationType = "CREATE")
    public Result<Map<String, Object>> batchSubmit(
            @RequestBody Map<String, Object> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null) {
            return new Result<>(401, null, "请先登录");
        }
        try {
            @SuppressWarnings("unchecked")
            List<Object> rawIds = (List<Object>) request.get("bookIds");
            String approvalType = (String) request.get("approvalType");
            if (rawIds == null || rawIds.isEmpty()) {
                return new Result<>(400, null, "请选择要申请的商品");
            }
            if (approvalType == null || (!"RESTORE".equals(approvalType) && !"DELETE".equals(approvalType))) {
                return new Result<>(400, null, "申请类型无效");
            }
            List<Integer> bookIds = new java.util.ArrayList<>();
            for (Object id : rawIds) {
                bookIds.add(Integer.valueOf(id.toString()));
            }
            int count = approvalService.batchSubmitApproval(bookIds, approvalType, user.getId(), user.getUsername());
            Map<String, Object> data = new java.util.HashMap<>();
            data.put("count", count);
            data.put("total", bookIds.size());
            return new Result<>(200, data, "已提交 " + count + " 条申请，等待管理员审批");
        } catch (Exception e) {
            return new Result<>(500, null, "操作失败，请稍后重试");
        }
    }

    /* ==================== 辅助方法 ==================== */

    private SysUser getCurrentUser(String authHeader) {
        try {
            String token = jwtUtil.extractTokenFromHeader(authHeader);
            if (token == null || !jwtUtil.validateToken(token)) {
                return null;
            }
            Long userId = jwtUtil.getUserIdFromToken(token);
            if (userId == null) return null;
            return userService.getById(userId);
        } catch (Exception e) {
            return null;
        }
    }

    private SysUser getAdminUser(String authHeader) {
        SysUser user = getCurrentUser(authHeader);
        if (user == null || user.getRole() == null || user.getRole() != 1) {
            return null;
        }
        return user;
    }
}
