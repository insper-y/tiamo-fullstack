package com.tiamo.controller;

import com.tiamo.annotation.OperationLog;
import com.tiamo.common.Result;
import com.tiamo.entity.SysUser;
import com.tiamo.security.JwtUtil;
import com.tiamo.service.CacheService;
import com.tiamo.service.impl.SysUserServiceImpl;
import com.tiamo.service.InviteCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 管理员 Controller
 * 提供用户管理等接口，仅管理员可访问
 * 所有接口路径: /api/admin/**
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private SysUserServiceImpl userService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private InviteCodeService inviteCodeService;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private static final String USER_LIST_CACHE_KEY = "tiamo:users:list";

    /**
     * 获取用户列表（仅管理员）
     * GET /api/admin/users
     */
    @GetMapping("/users")
    @OperationLog(module = "用户管理", description = "获取用户列表", operationType = "QUERY")
    public Result<List<Map<String, Object>>> getUserList(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser currentUser = getAdminUser(authHeader);
        if (currentUser == null) {
            return new Result<>(403, null, "无权限访问，仅管理员可操作");
        }

        // 先从缓存读取
        try {
            Object cachedObj = redisTemplate.opsForValue().get(USER_LIST_CACHE_KEY);
            if (cachedObj != null && cachedObj instanceof List) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> cachedList = (List<Map<String, Object>>) cachedObj;
                if (!cachedList.isEmpty()) {
                    return new Result<>(200, cachedList, "查询成功(缓存)");
                }
            }
        } catch (Exception e) {
            // 缓存读取失败，继续查询数据库
        }

        // 缓存没有，查询数据库
        List<SysUser> users = userService.list();
        List<Map<String, Object>> userList = users.stream().map(user -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", user.getId());
            map.put("username", user.getUsername());
            map.put("nickname", user.getNickname());
            map.put("email", user.getEmail());
            map.put("phone", user.getPhone());
            map.put("role", user.getRole() != null ? user.getRole() : 0);
            map.put("roleName", (user.getRole() != null && user.getRole() == 1) ? "管理员" : "普通用户");
            map.put("status", user.getStatus());
            map.put("statusName", (user.getStatus() != null && user.getStatus() == 1) ? "启用" : "禁用");
            map.put("createTime", user.getCreateTime());
            return map;
        }).collect(Collectors.toList());

        // 写入缓存，30秒过期
        cacheService.set(USER_LIST_CACHE_KEY, userList, 30, TimeUnit.SECONDS);

        return new Result<>(200, userList, "查询成功");
    }

    /**
     * 设置用户角色（仅管理员）
     * PUT /api/admin/users/{id}/role
     * body: {"role": 0} 0-普通用户 1-管理员
     */
    @PutMapping("/users/{id}/role")
    @OperationLog(module = "用户管理", description = "设置用户角色", operationType = "UPDATE")
    public Result<String> updateUserRole(
            @PathVariable Long id,
            @RequestBody Map<String, Integer> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser currentUser = getAdminUser(authHeader);
        if (currentUser == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可操作");
        }
        Integer role = request.get("role");
        if (role == null || (role != 0 && role != 1)) {
            return new Result<>(400, null, "角色参数无效，0-普通用户 1-管理员");
        }
        // 不允许修改自己的角色
        if (currentUser.getId().equals(id)) {
            return new Result<>(400, null, "不能修改自己的角色");
        }
        SysUser user = userService.getById(id);
        if (user == null) {
            return new Result<>(404, null, "用户不存在");
        }
        // 不允许修改admin账号的权限
        if ("admin".equals(user.getUsername())) {
            return new Result<>(400, null, "不能修改admin账号的权限");
        }
        user.setRole(role);
        user.setUpdateTime(LocalDateTime.now());
        boolean flag = userService.updateById(user);
        if (flag) {
            cacheService.delete(USER_LIST_CACHE_KEY);
            String roleName = role == 1 ? "管理员" : "普通用户";
            return new Result<>(200, null, "已将用户 " + user.getUsername() + " 设置为" + roleName);
        }
        return new Result<>(500, null, "设置失败");
    }

    /**
     * 设置用户状态（仅管理员）
     * PUT /api/admin/users/{id}/status
     * body: {"status": 1} 0-禁用 1-启用
     */
    @PutMapping("/users/{id}/status")
    @OperationLog(module = "用户管理", description = "设置用户状态", operationType = "UPDATE")
    public Result<String> updateUserStatus(
            @PathVariable Long id,
            @RequestBody Map<String, Integer> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser currentUser = getAdminUser(authHeader);
        if (currentUser == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可操作");
        }
        Integer status = request.get("status");
        if (status == null || (status != 0 && status != 1)) {
            return new Result<>(400, null, "状态参数无效，0-禁用 1-启用");
        }
        // 不允许禁用自己
        if (currentUser.getId().equals(id)) {
            return new Result<>(400, null, "不能修改自己的状态");
        }
        SysUser user = userService.getById(id);
        if (user == null) {
            return new Result<>(404, null, "用户不存在");
        }
        // 不允许禁用admin账号
        if ("admin".equals(user.getUsername()) && status == 0) {
            return new Result<>(400, null, "不能禁用admin账号");
        }
        user.setStatus(status);
        user.setUpdateTime(LocalDateTime.now());
        boolean flag = userService.updateById(user);
        if (flag) {
            cacheService.delete(USER_LIST_CACHE_KEY);
            String statusName = status == 1 ? "启用" : "禁用";
            return new Result<>(200, null, "已将用户 " + user.getUsername() + " " + statusName);
        }
        return new Result<>(500, null, "设置失败");
    }

    /**
     * 删除用户（仅管理员，只能删除普通用户）
     * DELETE /api/admin/users/{id}
     */
    @DeleteMapping("/users/{id}")
    @OperationLog(module = "用户管理", description = "删除用户", operationType = "DELETE")
    public Result<String> deleteUser(
            @PathVariable Long id,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser currentUser = getAdminUser(authHeader);
        if (currentUser == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可操作");
        }
        // 不允许删除自己
        if (currentUser.getId().equals(id)) {
            return new Result<>(400, null, "不能删除自己");
        }
        SysUser user = userService.getById(id);
        if (user == null) {
            return new Result<>(404, null, "用户不存在");
        }
        // 不允许删除admin账号
        if ("admin".equals(user.getUsername())) {
            return new Result<>(400, null, "不能删除admin账号");
        }
        // 不允许删除管理员
        if (user.getRole() != null && user.getRole() == 1) {
            return new Result<>(400, null, "不能删除管理员账户");
        }
        boolean flag = userService.removeById(id);
        if (flag) {
            cacheService.delete(USER_LIST_CACHE_KEY);
            return new Result<>(200, null, "已删除用户 " + user.getUsername());
        }
        return new Result<>(500, null, "删除失败");
    }

    /**
     * 重置用户密码（仅管理员）
     * PUT /api/admin/users/{id}/password
     * body: {"newPassword": "xxx"}
     */
    @PutMapping("/users/{id}/password")
    @OperationLog(module = "用户管理", description = "重置用户密码", operationType = "UPDATE")
    public Result<String> resetUserPassword(
            @PathVariable Long id,
            @RequestBody Map<String, String> request,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser currentUser = getAdminUser(authHeader);
        if (currentUser == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可操作");
        }
        String newPassword = request.get("newPassword");
        if (newPassword == null || newPassword.length() < 8) {
            return new Result<>(400, null, "新密码至少8位");
        }
        SysUser user = userService.getById(id);
        if (user == null) {
            return new Result<>(404, null, "用户不存在");
        }
        boolean success = userService.resetPasswordById(id, newPassword);
        if (success) {
            return new Result<>(200, null, "用户 " + user.getUsername() + " 密码重置成功");
        }
        return new Result<>(500, null, "密码重置失败");
    }

    /**
     * 生成注册邀请码（仅管理员）
     * POST /api/admin/invite-code
     * 邀请码6位数字，3分钟有效，使用一次后失效
     */
    @PostMapping("/invite-code")
    @OperationLog(module = "用户管理", description = "生成注册邀请码", operationType = "CREATE")
    public Result<Map<String, Object>> generateInviteCode(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        SysUser currentUser = getAdminUser(authHeader);
        if (currentUser == null) {
            return new Result<>(403, null, "无权限操作，仅管理员可生成邀请码");
        }
        String code = inviteCodeService.generateCode();
        Map<String, Object> data = new HashMap<>();
        data.put("inviteCode", code);
        data.put("expireMinutes", 3);
        data.put("createdBy", currentUser.getUsername());
        return new Result<>(200, data, "邀请码生成成功，3分钟内有效");
    }

    /**
     * 从 Token 中获取用户并验证是否为管理员
     */
    private SysUser getAdminUser(String authHeader) {
        String token = jwtUtil.extractTokenFromHeader(authHeader);
        if (token == null || !jwtUtil.validateToken(token)) {
            return null;
        }
        Long userId = jwtUtil.getUserIdFromToken(token);
        if (userId == null) {
            return null;
        }
        SysUser user = userService.getById(userId);
        if (user == null || user.getRole() == null || user.getRole() != 1) {
            return null;
        }
        return user;
    }
}
